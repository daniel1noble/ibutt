#' Humidity data
#' Example humidity data taken from a hydrochron iButton
#' @format A raw csv file saved from the Hydrochron iButton
#' @name humidity
#' @docType data
NULL

#' Temperature data
#' Example temperature data taken from an iButton
#' @format A raw csv file saved from the iButton
#' @name temp
#' @docType data
NULL