library(testthat)
library(ibutt)

test_check("ibutt")
